//
//  ViewController.swift
//  CoreDataDemo_Adidev
//
//  Created by Ingo Ngoyama on 6/19/19.
//  Copyright © 2019 Ingo Ngoyama. All rights reserved.
//

import UIKit
import CoreData

class TaskViewController: UITableViewController{
    var items =  [Items]()
    
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        loadItems()
    }

//MARK: TBLVW DATASOURCE MTDS##################################
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return items.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "item", for: indexPath)
        let item = items[indexPath.row]
        cell.textLabel?.text = item.task
        cell.accessoryType = item.completed ? .checkmark : .none
        return cell
    }
    
//MARK: TABLEVW DLGT MTDS#########################
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        items[indexPath.row].completed = !items[indexPath.row].completed
        saveItems()
    }
    
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    //deletion...............................
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if (editingStyle == .delete){
            let item = items[indexPath.row]
            items.remove(at: indexPath.row)
            context.delete(item)
            
            do{
                try context.save()
            }catch{
                print("Error deleting task with \(error)")
            }
            tableView.deleteRows(at: [indexPath], with: .automatic)
            
        }
    }
    
    @IBAction func addButtonPressed(_ sender: Any) {
        var textField = UITextField()
        let alert = UIAlertController(title: "Add a new task", message: "", preferredStyle: .alert)
        let action = UIAlertAction(title: "Save", style: .default) { (action) in
            let newItem = Items(context: self.context)
            newItem.task  =  textField.text! // the task will be what ever we type in the textfield
            self.items.append(newItem)
            self.saveItems()
        }
        alert.addAction(action)
        alert.addTextField { (field) in
            textField = field
            textField.placeholder = "add a new task"
            
        }
        present(alert, animated: true, completion: nil)
    }
    
//MARK: MEMORY ACTIONS#####################################
    func saveItems(){
     
        
        do{
            try context.save()
        }catch{
            print("Error saving task with \(error)")
        }
        tableView.reloadData()
    }
    
    
    //for recall of data to tblvw on initial reload even after phone turned back on.
    func loadItems(){
        let request: NSFetchRequest<Items>  = Items.fetchRequest()
        
        do{
            items = try context.fetch(request)
        }catch{
            print("Error fetching data from context \(error)")
        }
        tableView.reloadData()
    }

}

